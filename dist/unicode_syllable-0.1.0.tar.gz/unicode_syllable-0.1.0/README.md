# Unicode_Syllable_Break


Syllable Break for Unicode text
## Installation

```bash
pip install unicode_syllable
